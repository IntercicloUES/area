/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package area.de.figuras;

import javax.swing.JOptionPane;

/**
 *
 * @author bryan
 */
public class AreaDeFiguras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          double baseCuadrado,halturaCuadrado, area=0, areaCirculo,areadecirculo=0,baseTriangulo,halturaTriangulo,areaTriangulo=0;
        int opcion;
        opcion=Integer.parseInt(JOptionPane.showInputDialog("elija una opcion \n 1-AREA DEL CUADRADO  \n 2-AREA DEL CIRCULO  \n 3-AREA DEL TRIANGULO "));
        while(opcion==1 || opcion==2 || opcion==3 ){
            switch (opcion) {
                case 1:
                        baseCuadrado=Double.parseDouble(JOptionPane.showInputDialog("ingrese la base del cuadrado"));
                        halturaCuadrado=Double.parseDouble(JOptionPane.showInputDialog("ingrese la altura del cuadrado"));
                    area=baseCuadrado*halturaCuadrado;
                    JOptionPane.showMessageDialog(null,"el area del cuadrado es:"+ area);
                    break;
                case 2:
                   areaCirculo=Double.parseDouble(JOptionPane.showInputDialog("ingrese el area del circulo"));
                    areadecirculo = 3.1416*areaCirculo * areaCirculo;
                    JOptionPane.showMessageDialog(null,"el area del circulo es:"+ areadecirculo);
                    break;
                case 3:
                   baseTriangulo=Double.parseDouble(JOptionPane.showInputDialog("ingrese la base del triangulo"));
                        halturaTriangulo=Double.parseDouble(JOptionPane.showInputDialog("ingrese la altura del triangulo"));
                    areaTriangulo=(baseTriangulo*halturaTriangulo)/2 ;
                    JOptionPane.showMessageDialog(null,"el area del cuadrado es:"+ areaTriangulo);
                    break;
                default:
                    break;
            }
           opcion=Integer.parseInt(JOptionPane.showInputDialog("elija una opcion \n 1-AREA DEL CUADRADO  \n 2-AREA DEL CIRCULO  \n 3-AREA DEL TRIANGULO "));
            
        }
    }
    
}
